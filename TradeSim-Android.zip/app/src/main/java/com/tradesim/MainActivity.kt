package com.tradesim

import android.app.*
import android.os.Bundle
import android.graphics.Color
import android.view.*
import android.widget.*
import java.util.Locale
import kotlin.math.roundToInt
import kotlin.random.Random

data class Asset(val symbol:String,val name:String,var price:Double)
data class Holding(var symbol:String,var qty:Double,var avg:Double)

class MainActivity:Activity(){
    private val assets=mutableListOf(
        Asset("BTC","Bitcoin",62500.0), Asset("ETH","Ethereum",2550.0),
        Asset("AAPL","Apple",226.0), Asset("TSLA","Tesla",328.0),
        Asset("NVDA","NVIDIA",145.0)
    )
    private val holdings=mutableMapOf<String,Holding>()
    private val history=mutableListOf<String>()
    private var cash=100000.0
    private lateinit var root:LinearLayout
    private lateinit var balance:TextView
    private lateinit var portfolio:TextView
    private fun tv(s:String,size:Float=16f):TextView=TextView(this).apply{
        text=s; textSize=size; setTextColor(Color.WHITE); setPadding(18,14,18,14)
    }
    override fun onCreate(b:Bundle?){super.onCreate(b); build()}
    private fun build(){
        root=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL;setBackgroundColor(Color.rgb(11,18,32))}
        val scroll=ScrollView(this); val box=LinearLayout(this).apply{orientation=LinearLayout.VERTICAL}
        box.addView(tv("TradeSim",30f)); box.addView(tv("PAPER TRADING • VIRTUAL MONEY ONLY",13f))
        balance=tv("",21f); box.addView(balance)
        portfolio=tv("",16f); box.addView(portfolio)
        box.addView(tv("Markets",23f))
        assets.forEach{a->box.addView(assetRow(a))}
        box.addView(tv("Recent trades",22f))
        val h=tv("",14f); box.addView(h)
        scroll.addView(box); root.addView(scroll); setContentView(root)
        refresh(h)
    }
    private fun assetRow(a:Asset):LinearLayout{
        val row=LinearLayout(this).apply{orientation=LinearLayout.HORIZONTAL}
        val info=tv("${a.symbol}\n${a.name}\n$${fmt(a.price)}",15f)
        row.addView(info,LinearLayout.LayoutParams(0,130,1f))
        val buy=Button(this).apply{text="BUY";setOnClickListener{trade(a,true)}}
        val sell=Button(this).apply{text="SELL";setOnClickListener{trade(a,false)}}
        row.addView(buy);row.addView(sell);return row
    }
    private fun trade(a:Asset,buying:Boolean){
        val q=EditText(this).apply{hint="Quantity";inputType=2}
        AlertDialog.Builder(this).setTitle("${if(buying)"Buy" else "Sell"} ${a.symbol}")
            .setMessage("Price: $${fmt(a.price)} • Virtual funds only")
            .setView(q).setPositiveButton("Confirm"){_,_-> 
                val qty=q.text.toString().toDoubleOrNull()?:0.0
                if(qty<=0){toast("Enter a valid quantity");return@setPositiveButton}
                if(buying){
                    val cost=qty*a.price
                    if(cost>cash){toast("Insufficient virtual cash");return@setPositiveButton}
                    cash-=cost; val old=holdings[a.symbol]
                    holdings[a.symbol]=if(old==null) Holding(a.symbol,qty,a.price)
                    else Holding(a.symbol,old.qty+qty,(old.avg*old.qty+a.price*qty)/(old.qty+qty))
                    history.add("Bought %.4f %s @ $%.2f".format(Locale.US,qty,a.symbol,a.price))
                }else{
                    val old=holdings[a.symbol]
                    if(old==null||qty>old.qty){toast("Not enough virtual units");return@setPositiveButton}
                    cash+=qty*a.price
                    val nq=old.qty-qty;if(nq==0.0) holdings.remove(a.symbol) else holdings[a.symbol]=old.copy(qty=nq)
                    history.add("Sold %.4f %s @ $%.2f".format(Locale.US,qty,a.symbol,a.price))
                }
                refresh(root.findViewWithTag("history") as? TextView)
            }.setNegativeButton("Cancel",null).show()
    }
    private fun refresh(hv:TextView?=null){
        assets.forEach{it.price*=1+(Random.nextDouble(-.012,.012))}
        balance.text="Virtual cash: $${fmt(cash)}"
        var value=cash
        holdings.values.forEach{h->value+=h.qty*(assets.first{it.symbol==h.symbol}.price)}
        portfolio.text="Portfolio value: $${fmt(value)}\nOpen positions: ${holdings.size}"
        val h=hv?:TextView(this)
        h.tag="history";h.text=if(history.isEmpty())"No trades yet." else history.takeLast(8).reversed().joinToString("\n")
    }
    private fun fmt(x:Double)=String.format(Locale.US,"%,.2f",x)
    private fun toast(s:String)=Toast.makeText(this,s,Toast.LENGTH_SHORT).show()
}

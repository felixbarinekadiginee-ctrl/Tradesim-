# TradeSim
A paper-trading Android demo using virtual money only.

Features:
- $100,000 starting virtual cash
- Simulated BTC, ETH, AAPL, TSLA and NVDA prices
- Buy/sell virtual assets
- Portfolio value and positions
- Recent trade history
- No deposits, withdrawals, or real-money trading

Build with Android Studio using the included Gradle project.
